package com.example.hito2;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Recuperar los datos del formulario
        String nombre = request.getParameter("usuarioOperador");
        String ID = request.getParameter("contrasenaOperador");
        //System.out.println(nombre);
        //System.out.println(ID);
        // Inicializar el mensaje de error
        String mensajeError = null;

        try {
            // Cargar el controlador JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); // o manejar la excepción de acuerdo a tus necesidades
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso");
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Operador WHERE ID_operador = ? AND nombre = ?")) {

            statement.setString(1, ID);
            statement.setString(2, nombre);

            // Ejecutar la consulta
            try (ResultSet resultSet = statement.executeQuery()) {
                // Verificar si se encontró el operador
                if (resultSet.next()) {
                    // Operador encontrado
                    // Realiza aquí las acciones necesarias si el operador existe
                    String nombreOperador = resultSet.getString("nombre");
                    System.out.println("Operador encontrado: " + nombreOperador);
                    // Obtiene o crea la sesión
                    HttpSession session = request.getSession();

                    // Guarda el nombre de usuario en la sesión
                    session.setAttribute("username", nombreOperador);
                    session.setAttribute("Id_operador", ID);

                } else {
                    // Operador no encontrado
                    mensajeError = "Usuario o contraseña incorrectos.";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejar las excepciones adecuadamente en un entorno de producción
            mensajeError = "Error en la base de datos.";
        }

        // Enviar la respuesta al cliente
        if (mensajeError != null) {
            // Mostrar el mensaje de error en la página
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><h2>Error:</h2><p>" + mensajeError + "</p></body></html>");
        } else {
            // Operador encontrado, puedes redirigir o mostrar otra página
            response.sendRedirect("operador_encontrado.jsp"); // Ajusta el nombre de la página según tu estructura
        }
    }
}
