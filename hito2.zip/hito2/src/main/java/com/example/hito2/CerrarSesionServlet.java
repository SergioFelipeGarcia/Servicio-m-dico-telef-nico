package com.example.hito2;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/CerrarSesionServlet")
public class CerrarSesionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Obtén la sesión
        HttpSession session = request.getSession();

        // Invalida la sesión (borra todas las variables de sesión)
        session.invalidate();

        // Redirige a la página de inicio de sesión
        response.sendRedirect("index.jsp"); // Ajusta el nombre de la página según tu estructura
    }
}
