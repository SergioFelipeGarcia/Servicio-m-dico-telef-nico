package com.example.hito2;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;

@WebServlet("/EditarLlamadaServlet")
public class EditarLlamadaServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el ID de la llamada a editar desde los parámetros de la solicitud
        int idLlamada = Integer.parseInt(request.getParameter("id"));

        // Obtener los datos de la llamada desde la base de datos
        ObtenerLlamadasDerivadasServlet.Llamada llamada = obtenerLlamadaPorId(idLlamada);

        // Guardar la llamada en el alcance de la solicitud
        request.setAttribute("llamada", llamada);

        // Redirigir a la página de modificarcaso.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("/modificarcaso.jsp");
        dispatcher.forward(request, response);
    }

    private ObtenerLlamadasDerivadasServlet.Llamada obtenerLlamadaPorId(int idLlamada) {
        ObtenerLlamadasDerivadasServlet.Llamada llamada = new ObtenerLlamadasDerivadasServlet.Llamada();

        // Lógica para obtener los datos de la llamada por su ID desde la base de datos utilizando JDBC
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso")) {
            String sql = "SELECT * FROM Llamada WHERE ID_llamada = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, idLlamada);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        llamada.setIdLlamada(resultSet.getInt("ID_llamada"));
                        llamada.setNumeroLlamante(resultSet.getString("numero_del_llamante"));
                        llamada.setTipoLlamada(resultSet.getString("Tipo_de_llamada"));
                        llamada.setFechaHora(resultSet.getString("Fecha_hora"));
                        llamada.setMotivo(resultSet.getString("motivo"));
                        llamada.setConsejoOperador(resultSet.getString("consejo_operador"));
                        llamada.setConsejoEspecialista(resultSet.getString("consejo_especialista"));
                        llamada.setObservacionMolesta(resultSet.getBoolean("observacion_llamada_molesta"));
                        // Setear más atributos según tu modelo de datos
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Maneja las excepciones de conexión a la base de datos
        }

        return llamada;
    }
}
