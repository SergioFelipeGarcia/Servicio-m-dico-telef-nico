package com.example.hito2;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;

@WebServlet("/EspecialistaServlet")
public class EspecialistaServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recuperar los datos del formulario
        String nombre  = request.getParameter("usuarioEspecialista");
        String ID = request.getParameter("contrasenaEspecialista");
        String mensajeError = null;

        try {
            // Cargar el controlador JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); // o manejar la excepción de acuerdo a tus necesidades
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso");
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Operador WHERE ID_operador = ? AND nombre = ?")) {

            statement.setString(1, ID);
            statement.setString(2, nombre );

            // Ejecutar la consulta
            try (ResultSet resultSet = statement.executeQuery()) {
                // Verificar si el especialista existe
                if (resultSet.next()) {
                    // Especialista autenticado, realiza acciones necesarias
                    HttpSession session = request.getSession();
                    session.setAttribute("usuarioEspecialista", nombre);
                    session.setAttribute("Id_especialista", nombre);

                    // Redirige a la página del especialista
                    response.sendRedirect("especialista.jsp");
                } else {
                    // Especialista no encontrado
                    mensajeError = "Usuario o contraseña incorrectos.";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejar las excepciones adecuadamente en un entorno de producción
            mensajeError = "Error en la base de datos.";
        }

        // Enviar la respuesta al cliente
        if (mensajeError != null) {
            // Mostrar el mensaje de error en la página
            response.setContentType("text/html");
            response.getWriter().println("<html><body><h2>Error:</h2><p>" + mensajeError + "</p></body></html>");
        }
    }
}