package com.example.hito2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ObtenerLlamadasDerivadasServlet")
public class ObtenerLlamadasDerivadasServlet extends HttpServlet {

    public static class Llamada {
        private int idLlamada;
        private String numeroLlamante;
        private String tipoLlamada;
        private String fechaHora;
        private String motivo;
        private String consejoOperador;
        private String consejoEspecialista;
        private boolean observacionMolesta;

        // Agregar constructores, getters y setters según sea necesario

        public int getIdLlamada() {
            return idLlamada;
        }

        public void setIdLlamada(int idLlamada) {
            this.idLlamada = idLlamada;
        }

        public String getNumeroLlamante() {
            return numeroLlamante;
        }

        public void setNumeroLlamante(String numeroLlamante) {
            this.numeroLlamante = numeroLlamante;
        }

        public String getTipoLlamada() {
            return tipoLlamada;
        }

        public void setTipoLlamada(String tipoLlamada) {
            this.tipoLlamada = tipoLlamada;
        }

        public String getFechaHora() {
            return fechaHora;
        }

        public void setFechaHora(String fechaHora) {
            this.fechaHora = fechaHora;
        }

        public String getMotivo() {
            return motivo;
        }

        public void setMotivo(String motivo) {
            this.motivo = motivo;
        }

        public String getConsejoOperador() {
            return consejoOperador;
        }

        public void setConsejoOperador(String consejoOperador) {
            this.consejoOperador = consejoOperador;
        }

        public String getConsejoEspecialista() {
            return consejoEspecialista;
        }

        public void setConsejoEspecialista(String consejoEspecialista) {
            this.consejoEspecialista = consejoEspecialista;
        }

        public boolean isObservacionMolesta() {
            return observacionMolesta;
        }

        public void setObservacionMolesta(boolean observacionMolesta) {
            this.observacionMolesta = observacionMolesta;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lógica para obtener las llamadas desde la base de datos
        List<Llamada> llamadas = obtenerLlamadasDesdeBaseDeDatos();

        // Construir el contenido de la tabla en HTML
        String contenidoTabla = construirContenidoTabla(llamadas);

        // Enviar la respuesta como HTML
        response.setContentType("text/html");
        response.getWriter().write(contenidoTabla);
    }

    private List<Llamada> obtenerLlamadasDesdeBaseDeDatos() {
        List<Llamada> llamadas = new ArrayList<>();

        // Lógica para obtener las llamadas desde la base de datos utilizando JDBC
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso")) {
            String sql = "SELECT * FROM Llamada WHERE estado != 'cerrar' OR estado IS NULL";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        Llamada llamada = new Llamada();
                        llamada.setIdLlamada(resultSet.getInt("ID_llamada"));
                        llamada.setNumeroLlamante(resultSet.getString("numero_del_llamante"));
                        llamada.setTipoLlamada(resultSet.getString("Tipo_de_llamada"));
                        llamada.setFechaHora(resultSet.getString("Fecha_hora"));
                        llamada.setMotivo(resultSet.getString("motivo"));
                        llamada.setConsejoOperador(resultSet.getString("consejo_operador"));
                        llamada.setConsejoEspecialista(resultSet.getString("consejo_especialista"));
                        llamada.setObservacionMolesta(resultSet.getBoolean("observacion_llamada_molesta"));
                        // Setear más atributos según tu modelo de datos

                        llamadas.add(llamada);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Maneja las excepciones de conexión a la base de datos
        }

        return llamadas;
    }

    private String construirContenidoTabla(List<Llamada> llamadas) {
        StringBuilder contenidoTabla = new StringBuilder();

        // Cabecera de la tabla
        contenidoTabla.append("<tr>" +
                "<th>ID Llamada</th>" +
                "<th>Numero del llamante</th>" +
                "<th>Tipo de llamada</th>" +
                "<th>Fecha y Hora</th>" +
                "<th>Motivo</th>" +
                "<th>Consejo Operador</th>" +
                "<th>Consejo Especialista</th>" +
                "<th>Observación Llamada Molesta</th>" +
                "<th>Acciones</th>" +
                "</tr>");

        // Contenido de la tabla
        for (Llamada llamada : llamadas) {

            contenidoTabla.append("<tr>" +
                    "<td>" + llamada.idLlamada + "</td>" +
                    "<td>" + llamada.numeroLlamante + "</td>" +
                    "<td>" + llamada.tipoLlamada + "</td>" +
                    "<td>" + llamada.getFechaHora() + "</td>" +
                    "<td>" + llamada.getMotivo() + "</td>" +
                    "<td>" + llamada.getConsejoOperador() + "</td>" +
                    "<td>" + llamada.getConsejoEspecialista() + "</td>" +
                    "<td>" + llamada.isObservacionMolesta() + "</td>" +
                    "<td><a href='EditarLlamadaServlet?id=" + llamada.getIdLlamada() + "'>Editar</a></td>" +
                    "</tr>");
        }

        return contenidoTabla.toString();
    }
}
