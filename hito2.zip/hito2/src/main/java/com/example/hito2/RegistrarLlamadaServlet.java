package com.example.hito2;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.text.SimpleDateFormat;


@WebServlet("/RegistrarLlamadaServlet")
public class RegistrarLlamadaServlet extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Recuperar los datos del formulario
        String DNI = request.getParameter("dnipaciente");
        String telefono = request.getParameter("telefono");
        String motivo = request.getParameter("motivo");
        String tipoLlamada = request.getParameter("opcion");
        String consejo = request.getParameter("consejo");
        String estado = request.getParameter("estado");
        String nombrePaciente = request.getParameter("nombre");
        String mensajeError = null;
        // Obtiene la sesión
        HttpSession llamadaSession = request.getSession();
        // Recupera el id del operador de la sesión y el nombre del paciente que si no existe hay que darle de alta
        String idOpe = (String) llamadaSession.getAttribute("Id_operador");

        //

        // vemos si existe o no el paciente
        Boolean pacienteok = (boolean) llamadaSession.getAttribute("existepac");

        // Obtén la fecha y hora actual
        Date fechaHoraActual = new Date();

        // Define el formato deseado para MySQL DATETIME
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // Formatea la fecha y hora actual según el formato definido
        String fechaHoraFormateada = formato.format(fechaHoraActual);

        boolean observacion_llamada_molesta = false;

        if ("molesta".equals(tipoLlamada)) {
            observacion_llamada_molesta = true;
        }

        System.out.println("Dni :" + DNI + " telefono: " + telefono + " motivo:" + motivo + " IDoper:" + idOpe + " Tipo ll:" + tipoLlamada+ " consejo:" + consejo+ "estado:" +estado);

        try {
            // Cargar el controlador JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); // o manejar la excepción de acuerdo a tus necesidades
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso")){
            if (!pacienteok) {
                System.out.println ("antes del insertar el paciente" + DNI + nombrePaciente);
                // La condición es falsa, por lo tanto, se ejecuta el bloque de código dentro del if
                String insertPacienteQuery = "INSERT INTO Paciente (DNI, Nombre) VALUES (?, ?)";
                try (PreparedStatement pacienteStatement = connection.prepareStatement(insertPacienteQuery)) {
                    // Configurar los valores para la inserción
                    pacienteStatement.setString(1, DNI);
                    pacienteStatement.setString(2, nombrePaciente);
                    // Ejecutar la inserción
                    pacienteStatement.executeUpdate();

                } catch (SQLException e) {
                    e.printStackTrace(); // Manejar la excepción según tus necesidades
                    mensajeError = "Error al insertar en la tabla Paciente.";
                }
            }

            // Insertar datos de la llamada en la base de datos
             String insertCallQuery = "INSERT INTO Llamada (numero_del_llamante,Tipo_de_llamada,Fecha_hora,ID_operador,DNI_paciente,consejo_operador,motivo,observacion_llamada_molesta,estado) VALUES (?, ?, ?, ?, ?, ?,?,?,?)";
            try (PreparedStatement statement = connection.prepareStatement(insertCallQuery)) {
                statement.setString(1, telefono); // numero_del_llamante
                statement.setString(2, tipoLlamada); // Tipo_de_llamada
                statement.setString(3, fechaHoraFormateada);
                statement.setString(4, idOpe);
                statement.setString(5, DNI); // DNI_paciente
                statement.setString(6, consejo); // consejo_operado
                statement.setString(7, motivo); // Motivo
                statement.setBoolean(8,  observacion_llamada_molesta); //
                statement.setString(9, estado);// Estado
                statement.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejar las excepciones adecuadamente en un entorno de producción
            mensajeError = "Error en la base de datos.";
        }

        // Enviar la respuesta al cliente
        if (mensajeError != null) {
            // Mostrar el mensaje de error en la página
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><h2>Error:</h2><p>" + mensajeError + "</p></body></html>");
        } else {
            // Operador encontrado, puedes redirigir o mostrar otra página
            response.sendRedirect("operador_encontrado.jsp"); // Ajusta el nombre de la página según tu estructura
        }
    }
}
