package com.example.hito2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/GuardarModificacionServlet")
public class GuardarModificacionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los parámetros del formulario
        int idLlamada = Integer.parseInt(request.getParameter("idLlamada"));
        String numeroLlamante = request.getParameter("numeroLlamante");
        String tipoLlamada = request.getParameter("tipoLlamada");
        String fechaHora = request.getParameter("fechaHora");
        String motivo = request.getParameter("motivo");
        String consejoOperador = request.getParameter("consejoOperador");
        String consejoEspecialista = request.getParameter("consejoEspecialista");
        boolean observacionMolesta = request.getParameter("observacionMolesta") != null;
        String estado = request.getParameter("estado");
        // Lógica para actualizar los datos en la base de datos
        actualizarLlamadaEnBaseDeDatos(idLlamada, numeroLlamante, tipoLlamada, fechaHora, motivo, consejoOperador, consejoEspecialista, observacionMolesta, estado);

        // Redirigir a la página de éxito o donde desees
        response.sendRedirect("especialista.jsp");
    }

    private void actualizarLlamadaEnBaseDeDatos(int idLlamada, String numeroLlamante, String tipoLlamada,
                                                String fechaHora, String motivo, String consejoOperador,
                                                String consejoEspecialista, boolean observacionMolesta, String estado) {
        // Lógica para actualizar los datos de la llamada en la base de datos utilizando JDBC
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "curso")) {
            String sql = "UPDATE Llamada SET numero_del_llamante=?, Tipo_de_llamada=?, Fecha_hora=?, motivo=?, " +
                    "consejo_operador=?, consejo_especialista=?, observacion_llamada_molesta=?, estado=? WHERE ID_llamada=?";
            System.out.println (sql);
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, numeroLlamante);
                statement.setString(2, tipoLlamada);
                statement.setString(3, fechaHora);
                statement.setString(4, motivo);
                statement.setString(5, consejoOperador);
                statement.setString(6, consejoEspecialista);
                statement.setBoolean(7, observacionMolesta);
                statement.setString(8, estado);
                statement.setInt(9, idLlamada);

                // Ejecutar la actualización
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Maneja las excepciones de conexión a la base de datos
        }
    }
}
